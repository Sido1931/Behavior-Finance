# Reproduction guide

## Prerequisites

| Tool | Version | Used for |
|------|---------|----------|
| Python | 3.10+ | Phases 1–3 |
| Stata | 17+ | Phase 3 tables |

## Expected runtime (indicative)

| Step | Time |
|------|------|
| Phase 1 (`Code4_IVOL_Beta.py`) | 15–45 min |
| Phase 2 (`Code5_SKEW_ISKEW_IE.py`) | 20–60 min |
| Phase 3 Python | 5–20 min |
| Phase 3 Stata | 10–30 min |

## Step-by-step

### A. Data

Place three CSVs in `data/`, then:

```bash
python -c "from config.paths import check_data_files; m=check_data_files(); assert not m, m; print('data OK')"
```

### B. Full Python pipeline

```bash
python run_all.py
```

### C. Stata tables

From repo root:

```stata
do phase3_chen/stata/00_run_all_tables.do
```

### Key outputs

| Phase | File |
|-------|------|
| 1 | `phase1_baseline/ShareA_MonthlyData_IVOL_Beta.csv` |
| 2 | `phase2_asymmetry/SKEW_ISKEW_IE_Result.csv` |
| 3 | `phase3_chen/data/monthly_panel_chen.csv` |
| 3 | `phase3_chen/tables/*.tex` |

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Missing data | Copy CSVs to `data/` |
| Phase 2 fails | Run phase 1 first |
| Stata path error | `cd` to repo root before `do phase3_chen/stata/00_run_all_tables.do` |

## Maintainer

After refreshing code from `Baseline/`:

```bash
python tools/patch_portable_paths.py
```
