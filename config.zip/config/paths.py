# -*- coding: utf-8 -*-
"""Repository path constants (portable across OS)."""
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = REPO_ROOT / "data"
PHASE1_DIR = REPO_ROOT / "phase1_baseline"
PHASE2_DIR = REPO_ROOT / "phase2_asymmetry"
PHASE3_DIR = REPO_ROOT / "phase3_chen"

REQUIRED_DATA_FILES = (
    "ShareA_MonthlyData.csv",
    "ShareA_DailyData.csv",
    "Mkt_Rf_Daily.csv",
)


def data_dir_str() -> str:
    """Trailing slash for legacy Code1–4 `Directory` variable."""
    s = str(DATA_DIR).replace("\\", "/")
    return s if s.endswith("/") else s + "/"


def check_data_files() -> list[Path]:
    return [DATA_DIR / name for name in REQUIRED_DATA_FILES if not (DATA_DIR / name).exists()]
