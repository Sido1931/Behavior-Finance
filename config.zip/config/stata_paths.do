*===============================================================================
* config/stata_paths.do — portable paths (source after global REPO_ROOT is set)
* Run master script from repository root:
*   do phase3_chen/stata/00_run_all_tables.do
*===============================================================================
version 17

capture confirm global REPO_ROOT
if _rc {
    display as error "REPO_ROOT not set. cd to repo root and run 00_run_all_tables.do"
    exit 198
}

global PHASE3   "$REPO_ROOT/phase3_chen"
global THOUGHT  "$PHASE3"
global DATA     "$THOUGHT/data"
global PHASE1   "$REPO_ROOT/phase1_baseline"
global DATA_RAW "$REPO_ROOT/data"
global BASE     "$REPO_ROOT"

cap mkdir "$DATA"
cap mkdir "$THOUGHT/tables"
